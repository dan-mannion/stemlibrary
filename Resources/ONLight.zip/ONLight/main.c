//////////////////////////////////////////
// Code BEGINS here
// Ensure all lines below this are copied
//////////////////////////////////////////

#include <msp430G2553.h>

#define Red BIT1 // Connect Red LED to pin 2.1
#define Green BIT6 // Connect Green LED to pin 1.6
#define Blue BIT4 // Connect Blue LED to pin 2.4

volatile unsigned int Mode = 0; // System state variable, used in interrupt to cycle through colour modes
volatile unsigned int FadeR = 0; // Signifies if a colour effect contains fades, used in interrupt
volatile unsigned int FadeG = 2; // Signifies if a colour effect contains fades, used in interrupt
volatile unsigned int FadeB = 1; // Signifies if a colour effect contains fades, used in interrupt
volatile unsigned int FadeCount = 0;

void main(void)
{
WDTCTL = WDTPW + WDTHOLD; // Disable watchdog timer, set it to hold

P1DIR |= Green; // Pin 1.6 to output for green LED
P1SEL |= Green; // Assign pin 1.6 to timer output TA0.1
P1SEL2 &= ~Green; // Assign pin 1.6 to timer output TA0.1

TA0CCR0 = 1000-1; // Set maximum count value (PWM Period)
TA0CCTL1 = OUTMOD_3; // Set TA0.1 to output on counter reset, clear output on CCR1
TA0CCR1 = 500; // initialise counter compare value (duty fraction, out of 1000)
TA0CTL = TASSEL_2 + MC_1; // Use the SMCLK for the counter, and count upwards

P2DIR |= Red + Blue; // Pin 2.1 to output for red LED, pin 2.4 for output for blue LED
P2SEL |= Red + Blue; // Assign pin 2.1 (red) to timer output TA1.1 and pin 2.4 (blue) to timer output TA1.2
P2SEL2 &= ~Red + Blue; // Assign pin 2.1 (red) to timer output TA1.1 and pin 2.4 (blue) to timer output TA1.2

TA1CCR0 = 1000-1; // Set maximum count value (PWM Period)
TA1CCTL1 = OUTMOD_3; // set TA 1.1 to output on counter reset, clear output on CCR1
TA1CCTL2 = OUTMOD_3; // set TA 1.2 to output on counter reset, clear output on CCR2
TA1CCR1 = 500; // initialise counter compare value (duty fraction, out of 1000)
TA1CCR2 = 500; // initialise counter compare value (duty fraction, out of 1000)
TA1CTL = TASSEL_2 + MC_1; // Use the SMCLK for the counter, and count upwards

P1DIR &= ~BIT3; // Set pin 1.3 as input
P1OUT |= BIT3; // Enable high voltage on pin 1.3
P1REN |= BIT3; // Enable pull up resistor on pin 1.3
P1IES &= ~BIT3; // Enable rising edge interrupt on pin 1.3
P1IFG &= ~BIT3; // Remove any interrupt flag already present
P1IE |= BIT3; // Enable interrupts on pin 1.3

_BIS_SR(LPM1_bits+GIE); // Enter low power mode with global interrupts enabled
}

/* Port 1 interrupt to service the button press */
#pragma vector=PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
P1IFG &= ~BIT3; // Clear the interrupt flag that called this interrupt
P1IE &= ~BIT3; // Disable interrupt on this pin
WDTCTL = WDT_MDLY_32; // Start and set watchdog timer to trigger every 32ms
IFG1 &= ~WDTIFG; // Clear watchdog interrupt flag
IE1 |= WDTIE; // Enable watchdog interrupt

switch (Mode){

// RED only
case 0:
TA1CCR1 = 1000; // Red
TA0CCR1 = 0; // Green
TA1CCR2 = 0; // Blue
Mode = 1; // Mode to jump to on next button press
break;

// GREEN only
case 1:
TA1CCR1 = 0; // Red
TA0CCR1 = 1000; // Green
TA1CCR2 = 0; // Blue
Mode = 2; // Mode to jump to on next button press
break;

// BLUE only
case 2:
TA1CCR1 = 0; // Red
TA0CCR1 = 0; // Green
TA1CCR2 = 1000; // Blue
Mode = 3; // Mode to jump to on next button press
break;

// PURPLE only
case 3:
TA1CCR1 = 500; // Red
TA0CCR1 = 0; // Green
TA1CCR2 = 500; // Blue
Mode = 4; // Mode to jump to on next button press
break;

// ORANGE only
case 4:
TA1CCR1 = 500; // Red
TA0CCR1 = 200; // Green
TA1CCR2 = 0; // Blue
Mode = 5; // Mode to jump to on next button press
break;

// CYAN only
case 5:
TA1CCR1 = 0; // Red
TA0CCR1 = 500; // Green
TA1CCR2 = 200; // Blue
Mode = 6; // Mode to jump to on next button press
break;

////////////////////////////////////
// Special custom colour here //////
////////////////////////////////////
case 6:
TA1CCR1 = 700; // Red
TA0CCR1 = 100; // Green
TA1CCR2 = 100; // Blue
Mode = 99; // Mode to jump to on next button press
break;
////////////////////////////////////
// End of special custom colour here
////////////////////////////////////

case 99: // Special colour change fading mode
TA1CCTL0 = CCIE; // Enable counter interrupt on counter compare register 0
TA1CCR1 = 0; // Red
TA0CCR1 = 0; // Green
TA1CCR2 = 1000; // Blue
Mode = 100;
break;

case 100: // ‘Off’ State
TA1CCTL0 |= ~CCIE; // Disable counter interrupt on counter compare register 0
TA0CCTL1 = OUTMOD_1; // Disable counter interrupt on counter compare register 0
TA1CCTL1 = OUTMOD_1; // Disable counter interrupt on counter compare register 0
TA1CCTL2 = OUTMOD_1; // Disable counter interrupt on counter compare register 0
Mode = 101;
break;

case 101: // Return to default white state
TA0CCTL1 = OUTMOD_3; // Enable counter interrupt on counter compare register 0
TA1CCTL1 = OUTMOD_3; // Enable counter interrupt on counter compare register 0
TA1CCTL2 = OUTMOD_3; // Enable counter interrupt on counter compare register 0
FadeR = 0; // Signifies if a colour effect contains fades, used in interrupt
FadeG = 2; // Signifies if a colour effect contains fades, used in interrupt
FadeB = 1; // Signifies if a colour effect contains fades, used in interrupt
TA1CCR1 = 500; // Red
TA0CCR1 = 500; // Green
TA1CCR2 = 500; // Blue
Mode = 0;
break;

}
}

// Watchdog Interrupt Service Routine used to de-bounce button press
#pragma vector=WDT_VECTOR
__interrupt void WDT_ISR(void)
{
IE1 &= ~WDTIE; // Disable Watchdog timer interrupt
IFG1 &= ~WDTIFG; // Clear Watchdog interrupt flag
WDTCTL = WDTPW + WDTHOLD; // Return Watchdog to hold state
P1IE |= BIT3; // Reenable interrupts for pin 1.3
}

// Timer A1 interrupt service routine used for fade mode
#pragma vector=TIMER1_A0_VECTOR
__interrupt void Timer_A1 (void)
{
FadeCount = (FadeCount + 1) % 2 ; // Set speed of colour fade by modulus value

if(FadeCount == 0)
{

switch(FadeR){
case 0:
TA1CCR1 = (TA1CCR1 + 1);
if (TA1CCR1 == 999)
{FadeR = 1;}
break;
case 1:
TA1CCR1=(TA1CCR1-1);
if (TA1CCR1 == 0)
{FadeR = 2;}
break;
default:
FadeR = FadeR + 1;
if (FadeR == 1002)
{FadeR = 0;}
break;
}

switch(FadeG){
case 0:
TA0CCR1 = (TA0CCR1 + 1);
if (TA0CCR1 == 999)
{FadeG = 1;}
break;
case 1:
TA0CCR1 = (TA0CCR1 - 1);
if (TA0CCR1 == 0)
{FadeG = 2;}
break;
default:
FadeG = FadeG + 1;
if (FadeG == 1002)
{FadeG = 0;}
break;
}

switch(FadeB){
case 0:
TA1CCR2 = (TA1CCR2 + 1);
if (TA1CCR2 == 999)
{FadeB = 1;}
break;
case 1:
TA1CCR2 = (TA1CCR2 + 1);
if (TA1CCR2 == 0)
{FadeB = 2;}
break;
default:
FadeB = FadeB + 1;
if (FadeB == 1002)
{FadeB = 0;}
break;
}

}

}

//////////////////////////////////////////
// Code ENDS here
// Ensure all lines above this are copied
//////////////////////////////////////////
